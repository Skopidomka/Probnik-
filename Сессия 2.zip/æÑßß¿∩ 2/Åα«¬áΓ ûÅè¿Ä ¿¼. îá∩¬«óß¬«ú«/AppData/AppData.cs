﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Прокат_ЦПКиО_им.Маяковского.AppData
{
    public static class AppData
    {
        public static Entities db = new Entities();
    }
}